import { monkeyPatchMediaDevices } from './media-devices.js';

monkeyPatchMediaDevices();
